<?php
//index.php

echo "You found the index page! You aren't meant to be here. Please head back home";

?>

<!Doctype html>
<html>
<body>
<br>
<br>
<a href="home.html">Home</a>
</body>
</html>
	